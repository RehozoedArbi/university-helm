// ============================================================
// light.js — Charge légère et continue
// Objectif : maintenir des métriques/traces non vides en permanence
// pour que Prometheus et OpenTelemetry aient toujours du contenu.
// Active toutes les arêtes du graphe de dépendances OpenTelemetry.
//
// Lancement : ./run-load.sh light
// ou         : k6 run scripts/light.js
// ou avec URL custom : BASE_URL=http://172.18.0.2 k6 run scripts/light.js
// ============================================================

import http from 'k6/http';
import { check, sleep } from 'k6';
import { Counter, Trend } from 'k6/metrics';
import { STUDENT_URL, TEACHER_URL, ENROLLMENT_URL, TIMEOUT } from './config.js';

const errorsTotal  = new Counter('university_errors_total');
const latencyTrend = new Trend('university_latency_ms');

export const options = {
  vus:      2,
  duration: '24h',    // tourne en continu — stopper avec Ctrl+C
  thresholds: {
    http_req_failed:   ['rate<0.05'],
    http_req_duration: ['p(95)<2000'],
  },
};

// IDs fixes créés par setup-load.sh avant le premier run
const STUDENT_ID = 1;

export default function () {
  const params = {
    headers: { 'Content-Type': 'application/json' },
    timeout: TIMEOUT,
  };

  let r;

  // 1. GET /api/students → student-service
  r = http.get(`${STUDENT_URL}`, params);
  check(r, { 'GET /students 200': (res) => res.status === 200 });
  latencyTrend.add(r.timings.duration);
  if (r.status !== 200) errorsTotal.add(1);
  sleep(0.5);

  // 2. GET /api/students/{id}/available-courses
  //    → student-service appelle teacher-admin-service
  r = http.get(`${STUDENT_URL}/${STUDENT_ID}/available-courses`, params);
  check(r, { 'GET /available-courses 200': (res) => res.status === 200 });
  latencyTrend.add(r.timings.duration);
  if (r.status !== 200) errorsTotal.add(1);
  sleep(0.5);

  // 3. GET /api/students/{id}/enrollments
  //    → student-service appelle enrollment-service
  r = http.get(`${STUDENT_URL}/${STUDENT_ID}/enrollments`, params);
  check(r, { 'GET /enrollments via student 200': (res) => res.status === 200 });
  latencyTrend.add(r.timings.duration);
  if (r.status !== 200) errorsTotal.add(1);
  sleep(0.5);

  // 4. GET /api/teachers/courses → teacher-admin-service direct
  r = http.get(`${TEACHER_URL}/courses`, params);
  check(r, { 'GET /courses 200': (res) => res.status === 200 });
  latencyTrend.add(r.timings.duration);
  if (r.status !== 200) errorsTotal.add(1);
  sleep(0.5);

  // 5. GET /api/enrollments → enrollment-service direct
  r = http.get(`${ENROLLMENT_URL}`, params);
  check(r, { 'GET /enrollments direct 200': (res) => res.status === 200 });
  latencyTrend.add(r.timings.duration);
  if (r.status !== 200) errorsTotal.add(1);
  sleep(1);
}
